<?php

namespace App\Http\Controllers;

use App\Models\Lelang;
use App\Models\Penawaran;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BaseController extends Controller
{
    // Admin Logic
    public function adminView()
    {
        return view('admin.home');
    }

    public function pegawaiProfile()
    {
        return view('admin.profile_pegawai');
    }

    public function updateProfile(Request $request)
    {
        dd($request->all());
        $data = $request->all();

        $validData = Validator::make($data, [
            'nama_petugas' => ['required'],
            'foto' => ['image', 'mimes:png,jpg,jpeg', 'max:5000', 'min:1000'],
            'alamat' => ['max:50'],
            'tgl_lahir' => ['date'],
            'nomor_telp' => [] 
        ]);
    }

    //Web logic
    public function webView()
    {
        $mulai = Lelang::with(['petugas', 'user', 'barang'])
        ->where('tgl_mulai', '<=', now())
        ->where('tgl_selesai', '>=', now())
        ->paginate(9);

        return view('web.home', [
            "dataArr" => $mulai,
        ]);
    }
}
