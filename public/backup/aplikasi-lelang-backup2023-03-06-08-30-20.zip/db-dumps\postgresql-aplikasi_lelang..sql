--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: kontaks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kontaks (
    id bigint NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.kontaks OWNER TO postgres;

--
-- Name: kontaks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.kontaks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.kontaks_id_seq OWNER TO postgres;

--
-- Name: kontaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.kontaks_id_seq OWNED BY public.kontaks.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_resets OWNER TO postgres;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: tb_backup_barang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_backup_barang (
    id bigint NOT NULL,
    kategori_id bigint NOT NULL,
    nama_barang character varying(255) NOT NULL,
    harga_barang character varying(255) NOT NULL,
    deskripsi_barang text NOT NULL,
    status_lelang character varying(255) DEFAULT 'ditutup'::character varying NOT NULL,
    proses character varying(255) DEFAULT 'belum'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT tb_backup_barang_proses_check CHECK (((proses)::text = ANY ((ARRAY['belum'::character varying, 'sedang'::character varying, 'sudah'::character varying])::text[]))),
    CONSTRAINT tb_backup_barang_status_lelang_check CHECK (((status_lelang)::text = ANY ((ARRAY['ditutup'::character varying, 'dibuka'::character varying])::text[])))
);


ALTER TABLE public.tb_backup_barang OWNER TO postgres;

--
-- Name: tb_backup_barang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_backup_barang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_backup_barang_id_seq OWNER TO postgres;

--
-- Name: tb_backup_barang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_backup_barang_id_seq OWNED BY public.tb_backup_barang.id;


--
-- Name: tb_barang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_barang (
    id bigint NOT NULL,
    kategori_id bigint NOT NULL,
    nama_barang character varying(255) NOT NULL,
    harga_barang character varying(255) NOT NULL,
    deskripsi_barang text NOT NULL,
    foto character varying(255),
    status_lelang character varying(255) DEFAULT 'ditutup'::character varying NOT NULL,
    proses character varying(255) DEFAULT 'belum'::character varying NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT tb_barang_proses_check CHECK (((proses)::text = ANY ((ARRAY['belum'::character varying, 'sedang'::character varying, 'sudah'::character varying])::text[]))),
    CONSTRAINT tb_barang_status_lelang_check CHECK (((status_lelang)::text = ANY ((ARRAY['ditutup'::character varying, 'dibuka'::character varying])::text[])))
);


ALTER TABLE public.tb_barang OWNER TO postgres;

--
-- Name: tb_barang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_barang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_barang_id_seq OWNER TO postgres;

--
-- Name: tb_barang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_barang_id_seq OWNED BY public.tb_barang.id;


--
-- Name: tb_history_lelang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_history_lelang (
    id bigint NOT NULL,
    kategori_id bigint NOT NULL,
    petugas_id bigint NOT NULL,
    user_id bigint NOT NULL,
    nama_barang character varying(255) NOT NULL,
    harga_barang character varying(255) NOT NULL,
    harga_lelang character varying(255) NOT NULL,
    tgl_lelang date NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tb_history_lelang OWNER TO postgres;

--
-- Name: tb_history_lelang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_history_lelang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_history_lelang_id_seq OWNER TO postgres;

--
-- Name: tb_history_lelang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_history_lelang_id_seq OWNED BY public.tb_history_lelang.id;


--
-- Name: tb_kategori; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_kategori (
    id bigint NOT NULL,
    nama_kategori character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tb_kategori OWNER TO postgres;

--
-- Name: tb_kategori_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_kategori_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_kategori_id_seq OWNER TO postgres;

--
-- Name: tb_kategori_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_kategori_id_seq OWNED BY public.tb_kategori.id;


--
-- Name: tb_lelang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_lelang (
    id bigint NOT NULL,
    barang_id bigint,
    user_id bigint,
    petugas_id bigint,
    tgl_mulai date NOT NULL,
    tgl_selesai date NOT NULL,
    tgl_lelang date,
    harga_awal character varying(255) NOT NULL,
    harga_lelang character varying(255),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tb_lelang OWNER TO postgres;

--
-- Name: tb_lelang_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_lelang_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_lelang_id_seq OWNER TO postgres;

--
-- Name: tb_lelang_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_lelang_id_seq OWNED BY public.tb_lelang.id;


--
-- Name: tb_masyarakat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_masyarakat (
    id bigint NOT NULL,
    nama_lengkap character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    telp character varying(15) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tb_masyarakat OWNER TO postgres;

--
-- Name: tb_masyarakat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_masyarakat_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_masyarakat_id_seq OWNER TO postgres;

--
-- Name: tb_masyarakat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_masyarakat_id_seq OWNED BY public.tb_masyarakat.id;


--
-- Name: tb_penawaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_penawaran (
    id bigint NOT NULL,
    barang_id bigint NOT NULL,
    user_id bigint NOT NULL,
    harga_penawaran character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tb_penawaran OWNER TO postgres;

--
-- Name: tb_penawaran_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_penawaran_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_penawaran_id_seq OWNER TO postgres;

--
-- Name: tb_penawaran_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_penawaran_id_seq OWNED BY public.tb_penawaran.id;


--
-- Name: tb_pengajuan_lelangs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_pengajuan_lelangs (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    kategori_id bigint NOT NULL,
    nama_barang character varying(255) NOT NULL,
    lelang_dimulai date NOT NULL,
    lelang_diekhiri date NOT NULL,
    jenis_transaksi character varying(255) NOT NULL,
    status_pengajuan character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT tb_pengajuan_lelangs_jenis_transaksi_check CHECK (((jenis_transaksi)::text = ANY ((ARRAY['jual'::character varying, 'sewa'::character varying])::text[]))),
    CONSTRAINT tb_pengajuan_lelangs_status_pengajuan_check CHECK (((status_pengajuan)::text = ANY ((ARRAY['disetujui'::character varying, 'tidak_setujui'::character varying])::text[])))
);


ALTER TABLE public.tb_pengajuan_lelangs OWNER TO postgres;

--
-- Name: tb_pengajuan_lelangs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_pengajuan_lelangs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_pengajuan_lelangs_id_seq OWNER TO postgres;

--
-- Name: tb_pengajuan_lelangs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_pengajuan_lelangs_id_seq OWNED BY public.tb_pengajuan_lelangs.id;


--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tb_petugas (
    id bigint NOT NULL,
    nama_petugas character varying(255) NOT NULL,
    tgl_lahir date,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    alamat text,
    foto character varying(255),
    telp character varying(25) NOT NULL,
    role character varying(255) DEFAULT 'admin'::character varying NOT NULL,
    email_verified_at timestamp(0) without time zone,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    CONSTRAINT tb_petugas_role_check CHECK (((role)::text = ANY ((ARRAY['admin'::character varying, 'petugas'::character varying])::text[])))
);


ALTER TABLE public.tb_petugas OWNER TO postgres;

--
-- Name: tb_petugas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tb_petugas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tb_petugas_id_seq OWNER TO postgres;

--
-- Name: tb_petugas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tb_petugas_id_seq OWNED BY public.tb_petugas.id;


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: kontaks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kontaks ALTER COLUMN id SET DEFAULT nextval('public.kontaks_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: tb_backup_barang id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_backup_barang ALTER COLUMN id SET DEFAULT nextval('public.tb_backup_barang_id_seq'::regclass);


--
-- Name: tb_barang id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_barang ALTER COLUMN id SET DEFAULT nextval('public.tb_barang_id_seq'::regclass);


--
-- Name: tb_history_lelang id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_history_lelang ALTER COLUMN id SET DEFAULT nextval('public.tb_history_lelang_id_seq'::regclass);


--
-- Name: tb_kategori id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kategori ALTER COLUMN id SET DEFAULT nextval('public.tb_kategori_id_seq'::regclass);


--
-- Name: tb_lelang id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_lelang ALTER COLUMN id SET DEFAULT nextval('public.tb_lelang_id_seq'::regclass);


--
-- Name: tb_masyarakat id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_masyarakat ALTER COLUMN id SET DEFAULT nextval('public.tb_masyarakat_id_seq'::regclass);


--
-- Name: tb_penawaran id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_penawaran ALTER COLUMN id SET DEFAULT nextval('public.tb_penawaran_id_seq'::regclass);


--
-- Name: tb_pengajuan_lelangs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_pengajuan_lelangs ALTER COLUMN id SET DEFAULT nextval('public.tb_pengajuan_lelangs_id_seq'::regclass);


--
-- Name: tb_petugas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_petugas ALTER COLUMN id SET DEFAULT nextval('public.tb_petugas_id_seq'::regclass);


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: kontaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kontaks (id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_resets_table	1
3	2019_08_19_000000_create_failed_jobs_table	1
4	2019_12_14_000001_create_personal_access_tokens_table	1
5	2023_01_31_131508_create_barangs_table	1
6	2023_01_31_131537_create_lelangs_table	1
7	2023_01_31_131815_create_petugas_table	1
8	2023_01_31_133423_create_history_lelangs_table	1
9	2023_02_04_224058_create_penawarans_table	1
10	2023_02_04_225635_create_kategoris_table	1
11	2023_02_08_133015_create_pengajuan_lelangs_table	1
12	2023_02_13_093459_create_backup_barangs_table	1
13	2023_02_19_203010_create_kontaks_table	1
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_resets (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_backup_barang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_backup_barang (id, kategori_id, nama_barang, harga_barang, deskripsi_barang, status_lelang, proses, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_barang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_barang (id, kategori_id, nama_barang, harga_barang, deskripsi_barang, foto, status_lelang, proses, created_at, updated_at) FROM stdin;
1	9	Laudantium qui omnis nostrum.	130879	Consectetur deleniti nesciunt soluta ad qui ut nostrum. Eum fuga dolore aliquid quia. Voluptatum nulla eaque magni est asperiores. Deserunt est assumenda tenetur occaecati qui dolorem quam.	https://via.placeholder.com/1918x819.png/00ccee?text=electronics+veniam	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
2	2	Qui enim magni sint.	262912	Aut ut inventore molestiae at odit. Expedita maxime qui quis voluptatem aperiam velit. Illo omnis placeat hic quis consequatur dolores. Et blanditiis mollitia quis in sit incidunt.	https://via.placeholder.com/1918x819.png/0066cc?text=electronics+nostrum	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
3	6	Atque quasi delectus voluptatem pariatur libero.	849902	Maiores repellendus veniam ad. Recusandae consectetur enim pariatur rerum odit. Blanditiis accusantium nulla sequi libero. Autem sint occaecati laborum dolorem quo dolorem velit.	https://via.placeholder.com/1918x819.png/00cc11?text=electronics+earum	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
4	11	Sed velit recusandae error ut.	335174	Placeat repellat deleniti deleniti libero. Cumque odio sapiente voluptas pariatur sequi est velit atque. Dolore harum libero nulla dolorem repellendus expedita repudiandae. Quos qui consequatur illum qui omnis et ipsam.	https://via.placeholder.com/1918x819.png/00ddff?text=electronics+maiores	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
5	2	Omnis nam facilis ipsa.	200232	Fuga et ipsam aut dolores et dolores. Explicabo aperiam sit dolor quisquam. Est et dolore est molestias quasi culpa non in.	https://via.placeholder.com/1918x819.png/00dd44?text=electronics+impedit	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
6	14	Unde perferendis nulla aut esse.	361058	Sit ullam voluptatem deleniti quasi dolore. Impedit illo aliquid sapiente saepe labore quia. Harum deleniti perspiciatis consectetur reiciendis nesciunt dicta.	https://via.placeholder.com/1918x819.png/0066aa?text=electronics+repellat	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
7	15	Nihil nihil numquam sed aut nobis accusantium.	123089	Magni rem laudantium quia velit. Mollitia ullam eos consequatur ea libero.	https://via.placeholder.com/1918x819.png/001144?text=electronics+eos	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
8	12	Quaerat omnis ut quia voluptas.	534528	Cumque odit quibusdam rerum ut quibusdam voluptate quae. Fugiat sed ut quis qui. Excepturi nostrum consequatur aut nemo consequatur libero totam. Alias non sed ducimus et. Ut ut ut consectetur expedita aut tenetur.	https://via.placeholder.com/1918x819.png/00dd22?text=electronics+ea	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
9	14	Odit quae magni eos fugiat mollitia.	410909	Quia dolores nulla dignissimos excepturi voluptatibus. Quod sit error eveniet labore quis exercitationem totam.	https://via.placeholder.com/1918x819.png/00bbee?text=electronics+rerum	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
10	13	Suscipit accusantium nulla odio assumenda.	158535	Et et ipsum consectetur at ipsa unde sequi. Consequuntur tenetur blanditiis sunt dolores.	https://via.placeholder.com/1918x819.png/008888?text=electronics+similique	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
11	3	Modi consectetur ut facere alias nesciunt quia.	951684	Temporibus tenetur quisquam fugit quia. Voluptate aut delectus ut est aut. Cum saepe illo iusto sed quia labore. Neque architecto corporis voluptas occaecati culpa.	https://via.placeholder.com/1918x819.png/00bbee?text=electronics+fuga	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
12	2	Fugiat vel earum est eius aut.	726928	Et consequatur mollitia itaque. Ea blanditiis beatae consectetur quisquam nostrum voluptates. Dolorum voluptatem consectetur nihil quas.	https://via.placeholder.com/1918x819.png/005588?text=electronics+magnam	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
13	15	Architecto et tempora exercitationem possimus.	451734	Et fugiat corrupti facilis quis aliquid quidem culpa. Blanditiis occaecati a sit ut voluptates cum voluptatibus. In voluptas atque dignissimos placeat. Ratione et magnam consequuntur reprehenderit ratione.	https://via.placeholder.com/1918x819.png/007788?text=electronics+molestiae	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
14	7	A voluptas recusandae ut nostrum.	739646	Fuga et ipsum dolore maiores. Nesciunt modi omnis est hic. Eligendi et harum vel quis quia et. Ea molestiae error maxime dolor.	https://via.placeholder.com/1918x819.png/0000dd?text=electronics+nisi	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
15	15	Quasi sit alias at inventore consequatur tempore.	578390	Officia sed ea aut ut. Dignissimos architecto est temporibus. Nam nostrum quas perferendis et labore qui.	https://via.placeholder.com/1918x819.png/003355?text=electronics+culpa	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
16	13	Ut nam consectetur dolor eligendi et.	881298	Atque tempore laborum nostrum earum vero et consequatur autem. Est et voluptates est. Esse sint exercitationem fugiat dolor. Dolor est sed eius non totam.	https://via.placeholder.com/1918x819.png/00bbbb?text=electronics+expedita	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
17	7	Quaerat sit adipisci fugit repellendus et.	897757	Accusantium consectetur vel sit velit possimus cumque aut. Consequatur voluptatem eos consequatur delectus. Cupiditate facere est aut iure. Explicabo a temporibus sit voluptas quas sequi.	https://via.placeholder.com/1918x819.png/00bb44?text=electronics+reiciendis	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
18	9	Rerum qui quaerat cum.	385649	Tenetur omnis et iure eos unde. Eos molestiae esse voluptas tempora distinctio ipsam exercitationem. Alias veritatis id illum qui. Omnis nihil qui enim perferendis ipsa id.	https://via.placeholder.com/1918x819.png/006699?text=electronics+sunt	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
19	9	In officia fugit minus assumenda soluta nam.	276767	Quasi soluta aliquid sed officia sit reiciendis. Totam voluptate eum incidunt et. Tempora et perspiciatis in impedit quaerat mollitia ut.	https://via.placeholder.com/1918x819.png/00bb55?text=electronics+fugit	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
20	14	Exercitationem quaerat praesentium at amet deserunt quidem.	607372	Omnis et vel hic quas velit quaerat. Possimus quis officia tenetur aliquam quia consequatur dignissimos. Inventore accusamus sed mollitia vero.	https://via.placeholder.com/1918x819.png/00ddbb?text=electronics+similique	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
21	10	Itaque tempora praesentium dolor esse.	183561	Quasi vitae consequatur aperiam voluptatem consequatur praesentium. Id dolor earum non consequatur aliquid soluta. Eum incidunt doloribus rem est vel.	https://via.placeholder.com/1918x819.png/00ee66?text=electronics+et	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
22	11	Minima nihil aperiam eos unde.	376686	Placeat dolorem sequi alias id fugiat qui saepe sint. Consequatur animi dolores accusamus error. Rerum asperiores nostrum et ab ut earum.	https://via.placeholder.com/1918x819.png/00bbcc?text=electronics+ad	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
23	15	Magnam dolor fugit ut.	398312	Quia labore id soluta voluptas. Consectetur quidem aut est vel quidem. Commodi molestias esse eius sapiente.	https://via.placeholder.com/1918x819.png/0055dd?text=electronics+nam	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
24	8	Voluptatibus et quam pariatur.	312509	Porro ut distinctio officia eos. Numquam nostrum rerum autem autem. Doloremque repellendus iusto veritatis magnam quisquam eos exercitationem aut.	https://via.placeholder.com/1918x819.png/00bbee?text=electronics+quia	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
25	6	Voluptatem quo at vel ut.	943847	Nulla similique et ad voluptas perspiciatis maxime. Est odit qui deleniti quis. Nesciunt deserunt aut est et aliquam qui odit. Aut harum amet beatae distinctio voluptate ut.	https://via.placeholder.com/1918x819.png/009966?text=electronics+a	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
26	13	Voluptatem sed iure voluptatem cupiditate error.	380345	Porro qui quia minima ut rerum. Rerum quo ipsam quo dignissimos. Est omnis ipsam fuga. Impedit sint consequatur doloribus ducimus.	https://via.placeholder.com/1918x819.png/001111?text=electronics+laudantium	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
27	13	Ea laboriosam nihil ratione.	920289	Dolores sed in fugiat quis sed ex fugit recusandae. Et temporibus modi et fugiat dolores soluta. Dolor doloribus omnis accusantium natus nulla iure rem. Optio sapiente earum dignissimos fugiat eos blanditiis est.	https://via.placeholder.com/1918x819.png/002277?text=electronics+eos	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
28	6	Tenetur aut consequatur quod provident.	387515	Est repellendus culpa sunt. Quae recusandae ut eius officiis quia possimus. Id dicta est est nihil in ipsam.	https://via.placeholder.com/1918x819.png/004411?text=electronics+accusamus	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
29	5	Blanditiis numquam cum aspernatur illo aut laboriosam.	554593	Praesentium neque cupiditate facilis sed. Quos voluptatem omnis ut necessitatibus quas magnam.	https://via.placeholder.com/1918x819.png/00ffbb?text=electronics+dolor	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
30	11	Voluptas quisquam id non dignissimos.	265168	Non rem dolor quod amet non. Debitis veniam saepe impedit optio quo.	https://via.placeholder.com/1918x819.png/00ee77?text=electronics+earum	ditutup	belum	2023-03-05 21:56:49	2023-03-05 21:56:49
\.


--
-- Data for Name: tb_history_lelang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_history_lelang (id, kategori_id, petugas_id, user_id, nama_barang, harga_barang, harga_lelang, tgl_lelang, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_kategori; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_kategori (id, nama_kategori, created_at, updated_at) FROM stdin;
1	Est qui.	2023-03-05 21:56:49	2023-03-05 21:56:49
2	Dolorum qui.	2023-03-05 21:56:49	2023-03-05 21:56:49
3	Voluptatibus qui impedit.	2023-03-05 21:56:49	2023-03-05 21:56:49
4	Voluptas asperiores.	2023-03-05 21:56:49	2023-03-05 21:56:49
5	Saepe sequi praesentium.	2023-03-05 21:56:49	2023-03-05 21:56:49
6	Suscipit inventore sit.	2023-03-05 21:56:49	2023-03-05 21:56:49
7	Sed molestiae.	2023-03-05 21:56:49	2023-03-05 21:56:49
8	Tenetur veritatis.	2023-03-05 21:56:49	2023-03-05 21:56:49
9	Excepturi accusamus eligendi.	2023-03-05 21:56:49	2023-03-05 21:56:49
10	Repellat tempora.	2023-03-05 21:56:49	2023-03-05 21:56:49
11	In dolor.	2023-03-05 21:56:49	2023-03-05 21:56:49
12	Aliquid non sed.	2023-03-05 21:56:49	2023-03-05 21:56:49
13	Eligendi magnam.	2023-03-05 21:56:49	2023-03-05 21:56:49
14	Consequuntur iste aut.	2023-03-05 21:56:49	2023-03-05 21:56:49
15	Assumenda voluptatem error.	2023-03-05 21:56:49	2023-03-05 21:56:49
\.


--
-- Data for Name: tb_lelang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_lelang (id, barang_id, user_id, petugas_id, tgl_mulai, tgl_selesai, tgl_lelang, harga_awal, harga_lelang, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_masyarakat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_masyarakat (id, nama_lengkap, email, password, telp, email_verified_at, remember_token, created_at, updated_at) FROM stdin;
1	Ibnu Syawal Aliefian	ibnuSyawal@gmail.com	$2y$10$Un7PHhn022B7Krqd/Sy.Y.VG1a3.LR/BthfwM1tJ7GzlwyysYzH0y	082162941198	\N	\N	\N	\N
2	Akhmad Alwan Rabbani	AlwanCoding@gmail.com	$2y$10$ZrRbeh/oUg6TSx8zo5ECp.ANpDKr6IFwbGBZGAcV9Yy.NzDgVkXZW	082162941194	\N	\N	\N	\N
3	Muhammad sholeh	VArlotte@gmail.com	$2y$10$IJAVi6bBspr0.KrfQsIX0uxvFqx8gNval3I4WCCAHiwhAJ8mV9twu	082162941192	\N	\N	\N	\N
4	Muhammad Rezzqi Rabbani	VanStrong@gmail.com	$2y$10$S.q7lv2xqZ/YyqfP2yUzze3zGdh4Q2UXp.zFyT7iJML/4GtAmQg02	082162941193	\N	\N	\N	\N
\.


--
-- Data for Name: tb_penawaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_penawaran (id, barang_id, user_id, harga_penawaran, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_pengajuan_lelangs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_pengajuan_lelangs (id, user_id, kategori_id, nama_barang, lelang_dimulai, lelang_diekhiri, jenis_transaksi, status_pengajuan, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tb_petugas (id, nama_petugas, tgl_lahir, email, password, alamat, foto, telp, role, email_verified_at, remember_token, created_at, updated_at) FROM stdin;
1	Uli Kusmawati S.Ked	\N	ihutapea@yahoo.co.id	$2y$10$VHtkmPALxcSmBgGvMSeSKuX4cG32h8ZEJ6RWU7abigqUuzUAlFflO	\N	\N	(+62) 627 2536 7287	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
2	Najib Simanjuntak S.Farm	\N	gada.nasyidah@yahoo.com	$2y$10$dv0D5a4gf6IQNSfSJH/5COp4ZkzC7J43TgaaUqGue.uszKD5BHoly	\N	\N	021 1189 8314	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
3	Vanya Yulianti	\N	nugraha97@gmail.co.id	$2y$10$vqc57KBLC/Jt0QV1ntvLbuPJB1w8CjhAj8KPXWoOr7.743m0tKgUy	\N	\N	(+62) 614 9262 6356	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
4	Liman Wardaya Pradana M.Ak	\N	prayoga27@yahoo.com	$2y$10$/I7yQKvLbHevFja6mg7my.wu7q554tpCu3EIl0ZuP1qYctAztJpne	\N	\N	0592 0427 508	admin	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
5	Daru Latupono	\N	ozy26@yahoo.co.id	$2y$10$PSjZIkCtXwa0UZrA87hSGOoT/jNwBkQAK0B1lV/ezxn7.8DTzfWri	\N	\N	(+62) 849 3358 217	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
6	Edward Latupono S.IP	\N	adhiarja36@gmail.com	$2y$10$jaANvqj0Vj9DfIDjqsicF.x9mfeYne85QOUKU647BXq7Zb/jjT/pG	\N	\N	0472 7188 6665	admin	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
7	Putu Putra	\N	znasyiah@gmail.com	$2y$10$KIYzmZWN7uLfEhn85Qa7d.XZ2PBNB8Dsp178dfH.m9zUwbbSztLvG	\N	\N	0868 5204 4436	admin	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
8	Yulia Zulaika	\N	damu.hassanah@gmail.com	$2y$10$jmtro/kZqhdzsZvNyySOhO/DyA0x6yiIL9PgmnNGLSIPdBKj8lGIe	\N	\N	(+62) 803 8199 622	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
9	Anita Wulandari	\N	hassanah.karta@yahoo.co.id	$2y$10$Dsql.yxIbQHJJqjtgaqaU.nhLBTtlyV8z0Er5Bj4UeQAfn43p/O.a	\N	\N	0223 9130 4892	petugas	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
10	Dina Haryanti	\N	handayani.puti@yahoo.co.id	$2y$10$wgyVrlnOO368xUpYC9q8Ae6ZFblZ3TZSkZRK7S.edZ884yPhkNuli	\N	\N	(+62) 887 3275 833	admin	\N	\N	2023-03-05 21:56:49	2023-03-05 21:56:49
\.


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: kontaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.kontaks_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 13, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 1, false);


--
-- Name: tb_backup_barang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_backup_barang_id_seq', 1, false);


--
-- Name: tb_barang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_barang_id_seq', 30, true);


--
-- Name: tb_history_lelang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_history_lelang_id_seq', 1, false);


--
-- Name: tb_kategori_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_kategori_id_seq', 15, true);


--
-- Name: tb_lelang_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_lelang_id_seq', 1, false);


--
-- Name: tb_masyarakat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_masyarakat_id_seq', 4, true);


--
-- Name: tb_penawaran_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_penawaran_id_seq', 1, false);


--
-- Name: tb_pengajuan_lelangs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_pengajuan_lelangs_id_seq', 1, false);


--
-- Name: tb_petugas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tb_petugas_id_seq', 10, true);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: kontaks kontaks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kontaks
    ADD CONSTRAINT kontaks_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: tb_backup_barang tb_backup_barang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_backup_barang
    ADD CONSTRAINT tb_backup_barang_pkey PRIMARY KEY (id);


--
-- Name: tb_barang tb_barang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_barang
    ADD CONSTRAINT tb_barang_pkey PRIMARY KEY (id);


--
-- Name: tb_history_lelang tb_history_lelang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_history_lelang
    ADD CONSTRAINT tb_history_lelang_pkey PRIMARY KEY (id);


--
-- Name: tb_kategori tb_kategori_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_kategori
    ADD CONSTRAINT tb_kategori_pkey PRIMARY KEY (id);


--
-- Name: tb_lelang tb_lelang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_lelang
    ADD CONSTRAINT tb_lelang_pkey PRIMARY KEY (id);


--
-- Name: tb_masyarakat tb_masyarakat_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_masyarakat
    ADD CONSTRAINT tb_masyarakat_email_unique UNIQUE (email);


--
-- Name: tb_masyarakat tb_masyarakat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_masyarakat
    ADD CONSTRAINT tb_masyarakat_pkey PRIMARY KEY (id);


--
-- Name: tb_penawaran tb_penawaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_penawaran
    ADD CONSTRAINT tb_penawaran_pkey PRIMARY KEY (id);


--
-- Name: tb_pengajuan_lelangs tb_pengajuan_lelangs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_pengajuan_lelangs
    ADD CONSTRAINT tb_pengajuan_lelangs_pkey PRIMARY KEY (id);


--
-- Name: tb_petugas tb_petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tb_petugas
    ADD CONSTRAINT tb_petugas_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- PostgreSQL database dump complete
--

